<?php 

function _handle_form_action(){

    echo 'iam here';exit;

}
?>